## 2.2.3
* fix the use item packet

## 2.2.2
* fix the block update packet, for real this time

## 2.1.1
* fix the block update packet

## 2.1.0
* normalize names of packet fields
* update to version 0.14.2

## 2.0.1
* player list is now an array
* reconnecting has been fixed

## 2.0.0

* lot of raknet update that fix bugs
* the server example is working
* fix packets
* breaking : remove mcpe_ prefix in packet names
* encapsulated packet now emit actual errors

## 1.1.0

* raknet is integrated, packet parsing is working
* client login sequence is working
* server login sequence is almost there

## 1.0.0

* first version, protocol definition is there but nothing really works
